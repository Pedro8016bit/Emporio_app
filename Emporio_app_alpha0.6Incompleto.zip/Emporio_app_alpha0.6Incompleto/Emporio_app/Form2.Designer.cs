﻿using System.ComponentModel;

namespace Emporio_app;

partial class Form2
{
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
        if (disposing && (components != null))
        {
            components.Dispose();
        }

        base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
        btnVoltar = new System.Windows.Forms.Button();
        label1 = new System.Windows.Forms.Label();
        comboBox1 = new System.Windows.Forms.ComboBox();
        label2 = new System.Windows.Forms.Label();
        numericUpDown1 = new System.Windows.Forms.NumericUpDown();
        label3 = new System.Windows.Forms.Label();
        comboBox2 = new System.Windows.Forms.ComboBox();
        label4 = new System.Windows.Forms.Label();
        textBox1 = new System.Windows.Forms.TextBox();
        button1 = new System.Windows.Forms.Button();
        ((System.ComponentModel.ISupportInitialize)numericUpDown1).BeginInit();
        SuspendLayout();
        // 
        // btnVoltar
        // 
        btnVoltar.Location = new System.Drawing.Point(11, 11);
        btnVoltar.Name = "btnVoltar";
        btnVoltar.Size = new System.Drawing.Size(80, 37);
        btnVoltar.TabIndex = 0;
        btnVoltar.Text = "Voltar";
        btnVoltar.UseVisualStyleBackColor = true;
        btnVoltar.Click += btnVoltar_Click_1;
        // 
        // label1
        // 
        label1.Location = new System.Drawing.Point(195, 53);
        label1.Name = "label1";
        label1.Size = new System.Drawing.Size(100, 23);
        label1.TabIndex = 1;
        label1.Text = "Produto";
        label1.Click += label1_Click;
        // 
        // comboBox1
        // 
        comboBox1.FormattingEnabled = true;
        comboBox1.Location = new System.Drawing.Point(163, 109);
        comboBox1.Name = "comboBox1";
        comboBox1.Size = new System.Drawing.Size(146, 23);
        comboBox1.TabIndex = 2;
        comboBox1.Text = "Produtos Disponiveis";
        // 
        // label2
        // 
        label2.Location = new System.Drawing.Point(486, 66);
        label2.Name = "label2";
        label2.Size = new System.Drawing.Size(100, 23);
        label2.TabIndex = 3;
        label2.Text = "Quantidade";
        // 
        // numericUpDown1
        // 
        numericUpDown1.Location = new System.Drawing.Point(466, 109);
        numericUpDown1.Name = "numericUpDown1";
        numericUpDown1.Size = new System.Drawing.Size(120, 23);
        numericUpDown1.TabIndex = 4;
        // 
        // label3
        // 
        label3.Location = new System.Drawing.Point(486, 232);
        label3.Name = "label3";
        label3.Size = new System.Drawing.Size(100, 23);
        label3.TabIndex = 5;
        label3.Text = "Filial";
        // 
        // comboBox2
        // 
        comboBox2.FormattingEnabled = true;
        comboBox2.Location = new System.Drawing.Point(465, 292);
        comboBox2.Name = "comboBox2";
        comboBox2.Size = new System.Drawing.Size(121, 23);
        comboBox2.TabIndex = 6;
        comboBox2.Text = "Filiais Disponiveis";
        // 
        // label4
        // 
        label4.Location = new System.Drawing.Point(195, 232);
        label4.Name = "label4";
        label4.Size = new System.Drawing.Size(100, 23);
        label4.TabIndex = 7;
        label4.Text = "Funcionario";
        label4.Click += label4_Click;
        // 
        // textBox1
        // 
        textBox1.Location = new System.Drawing.Point(163, 292);
        textBox1.Name = "textBox1";
        textBox1.Size = new System.Drawing.Size(100, 23);
        textBox1.TabIndex = 8;
        textBox1.Text = "txtFuncionario";
        textBox1.TextChanged += textBox1_TextChanged;
        // 
        // button1
        // 
        button1.Location = new System.Drawing.Point(163, 363);
        button1.Name = "button1";
        button1.Size = new System.Drawing.Size(124, 23);
        button1.TabIndex = 9;
        button1.Text = "Registrar Venda";
        button1.UseVisualStyleBackColor = true;
        // 
        // Form2
        // 
        AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
        AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
        ClientSize = new System.Drawing.Size(800, 450);
        Controls.Add(button1);
        Controls.Add(textBox1);
        Controls.Add(label4);
        Controls.Add(comboBox2);
        Controls.Add(label3);
        Controls.Add(numericUpDown1);
        Controls.Add(label2);
        Controls.Add(comboBox1);
        Controls.Add(label1);
        Controls.Add(btnVoltar);
        Text = "Form2";
        ((System.ComponentModel.ISupportInitialize)numericUpDown1).EndInit();
        ResumeLayout(false);
        PerformLayout();
    }

    private System.Windows.Forms.Button button1;

    private System.Windows.Forms.TextBox textBox1;

    private System.Windows.Forms.Label label4;

    private System.Windows.Forms.ComboBox comboBox2;

    private System.Windows.Forms.Label label3;

    private System.Windows.Forms.NumericUpDown numericUpDown1;

    private System.Windows.Forms.Label label2;

    private System.Windows.Forms.ComboBox comboBox1;

    private System.Windows.Forms.Label label1;

    private System.Windows.Forms.Button btnVoltar;

    #endregion
}