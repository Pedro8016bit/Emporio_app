namespace Emporio_app;

public partial class Form1 : Form
{
    public Form1()
    {
        InitializeComponent();
    }

    public class Usuario
    {
        public string Nome { get; set; }
        public string Senha { get; set; }

        public Usuario(string nome, string senha)
        {
            Nome = nome;
            Senha = senha;
        }
    }

    public class Produto
    {
        public string Nome { get; set; }
        public double Preco { get; set; }
        public int Estoque { get; set; }
        public int QuantidadeVendida { get; set; }
        public string FaixaEtaria { get; set; }

        public Produto(string nome, double preco, int estoque, string faixaEtaria)
        {
            Nome = nome;
            Preco = preco;
            Estoque = estoque;
            FaixaEtaria = faixaEtaria;
            QuantidadeVendida = 0;
        }

        public void RegistrarVenda(int quantidade)
        {
            if (quantidade <= Estoque)
            {
                Estoque -= quantidade;
                QuantidadeVendida += quantidade;
            }
            else
            {
                throw new Exception("Estoque insuficiente!");
            }
        }
    }

    public class Filial
    {
        public string Nome { get; set; }
        public List<Produto> Produtos { get; set; }

        public Filial(string nome)
        {
            Nome = nome;
            Produtos = new List<Produto>();
        }

        // Método para buscar um produto por nome
        public Produto BuscarProduto(string nome)
        {
            return Produtos.Find(p => p.Nome.Equals(nome, StringComparison.OrdinalIgnoreCase));
        }
    }

    public class Venda
    {
        public Produto Produto { get; set; }
        public int Quantidade { get; set; }
        public DateTime DataVenda { get; set; }
        public Usuario Funcionario { get; set; }
        public Filial Filial { get; set; }

        public Venda(Produto produto, int quantidade, Usuario funcionario, Filial filial)
        {
            Produto = produto;
            Quantidade = quantidade;
            DataVenda = DateTime.Now;
            Funcionario = funcionario;
            Filial = filial;
        }
    }
}
