namespace Emporio_app;

public partial class Form1 : Form
{
    private List<Usuario> usuarios = new List<Usuario>();

    public Form1()
    {
        InitializeComponent();
    }


    public class Usuario
    {
        public string Nome { get; set; }
        public string Senha { get; set; }

        public Usuario(string nome, string senha)
        {
            Nome = nome;
            Senha = senha;
        }
    }

    public class Produto
    {
        public string Nome { get; set; }
        public double Preco { get; set; }
        public int Estoque { get; set; }
        public int QuantidadeVendida { get; set; }
        public string FaixaEtaria { get; set; }

        public Produto(string nome, double preco, int estoque, string faixaEtaria)
        {
            Nome = nome;
            Preco = preco;
            Estoque = estoque;
            FaixaEtaria = faixaEtaria;
            QuantidadeVendida = 0;
        }

        public void RegistrarVenda(int quantidade)
        {
            if (quantidade <= Estoque)
            {
                Estoque -= quantidade;
                QuantidadeVendida += quantidade;
            }
            else
            {
                throw new Exception("Estoque insuficiente!");
            }
        }
    }

    public class Filial
    {
        public string Nome { get; set; }
        public List<Produto> Produtos { get; set; }

        public Filial(string nome)
        {
            Nome = nome;
            Produtos = new List<Produto>();
        }

        // Método para buscar um produto por nome
        public Produto BuscarProduto(string nome)
        {
            return Produtos.Find(p => p.Nome.Equals(nome, StringComparison.OrdinalIgnoreCase));
        }
    }

    public class Venda
    {
        public Produto Produto { get; set; }
        public int Quantidade { get; set; }
        public DateTime DataVenda { get; set; }
        public Usuario Funcionario { get; set; }
        public Filial Filial { get; set; }

        public Venda(Produto produto, int quantidade, Usuario funcionario, Filial filial)
        {
            Produto = produto;
            Quantidade = quantidade;
            DataVenda = DateTime.Now;
            Funcionario = funcionario;
            Filial = filial;
        }
    }

   private void escreve_login_TextChanged(object sender, EventArgs e)
    {
        escreve_login.Text = escreve_login.Text.Trim();
    }

    private void escreve_senha_TextChanged(object sender, EventArgs e)
    {
        if (string.IsNullOrEmpty(escreve_senha.Text))
        {
            MessageBox.Show("A senha não pode estar vazia!");
        }
    }

    private void btn_Acesso_Click(object sender, EventArgs e)
    {
        string nome = escreve_login.Text;
        string senha = escreve_senha.Text;

        var usuarioEncontrado = usuarios.Find(u => u.Nome == nome && u.Senha == senha);

        if (usuarioEncontrado != null)
        {
            Form2 segundoFormulario = new Form2();
            segundoFormulario.Show();
            this.Hide();
        }
        else
        {
            MessageBox.Show("Usuário ou senha incorretos!");
        }
    }

    private void btn_cad_Click(object sender, EventArgs e)
    {
        string nome = escreve_login.Text;
        string senha = escreve_senha.Text;

        if (!string.IsNullOrWhiteSpace(nome) && !string.IsNullOrWhiteSpace(senha))
        {
            usuarios.Add(new Usuario(nome, senha));
            MessageBox.Show("Usuário cadastrado com sucesso!");
        }
        else
        {
            MessageBox.Show("Preencha todos os campos!");
        }
    }

    private void Login_text_Click(object sender, EventArgs e)
    {
       throw new System.NotImplementedException();
    }

    private void senha_text_Click(object sender, EventArgs e)
    {
       throw new System.NotImplementedException();
    }
}
