﻿using System.ComponentModel;

namespace Emporio_app;

partial class Form2
{
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
        if (disposing && (components != null))
        {
            components.Dispose();
        }

        base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
        btnVoltar = new System.Windows.Forms.Button();
        SuspendLayout();
        // 
        // btnVoltar
        // 
        btnVoltar.Location = new System.Drawing.Point(11, 11);
        btnVoltar.Name = "btnVoltar";
        btnVoltar.Size = new System.Drawing.Size(80, 37);
        btnVoltar.TabIndex = 0;
        btnVoltar.Text = "Voltar";
        btnVoltar.UseVisualStyleBackColor = true;
        btnVoltar.Click += btnVoltar_Click_1;
        // 
        // Form2
        // 
        AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
        AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
        ClientSize = new System.Drawing.Size(800, 450);
        Controls.Add(btnVoltar);
        Text = "Form2";
        ResumeLayout(false);
    }

    private System.Windows.Forms.Button btnVoltar;

    #endregion
}