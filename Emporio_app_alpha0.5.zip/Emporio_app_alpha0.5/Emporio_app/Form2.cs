﻿namespace Emporio_app;

public partial class Form2 : Form
{
    public Form2()
    {
        InitializeComponent();
    }


    private void btnVoltar_Click_1(object sender, EventArgs e)
    {
        Form1 primeiroFormulario = new Form1();
        primeiroFormulario.Show();
        this.Close();
    }
}