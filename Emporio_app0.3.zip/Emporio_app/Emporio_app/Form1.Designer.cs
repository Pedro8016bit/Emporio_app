﻿namespace Emporio_app;

partial class Form1
{
    private System.ComponentModel.IContainer components = null;

    protected override void Dispose(bool disposing)
    {
        if (disposing && (components != null))
        {
            components.Dispose();
        }

        base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
        System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
        Login_text = new System.Windows.Forms.Label();
        escreve_login = new System.Windows.Forms.TextBox();
        senha_text = new System.Windows.Forms.Label();
        escreve_senha = new System.Windows.Forms.TextBox();
        btn_Acesso = new System.Windows.Forms.Button();
        btn_cad = new System.Windows.Forms.Button();
        pictureBox1 = new System.Windows.Forms.PictureBox();
        label1 = new System.Windows.Forms.Label();
        label2 = new System.Windows.Forms.Label();
        ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
        SuspendLayout();
        // 
        // Login_text
        // 
        Login_text.Location = new System.Drawing.Point(559, 217);
        Login_text.Name = "Login_text";
        Login_text.Size = new System.Drawing.Size(38, 18);
        Login_text.TabIndex = 0;
        Login_text.Text = "Login";
        Login_text.Click += Login_text_Click;
        // 
        // escreve_login
        // 
        escreve_login.BackColor = System.Drawing.Color.Silver;
        escreve_login.BorderStyle = System.Windows.Forms.BorderStyle.None;
        escreve_login.Location = new System.Drawing.Point(559, 238);
        escreve_login.Name = "escreve_login";
        escreve_login.Size = new System.Drawing.Size(100, 16);
        escreve_login.TabIndex = 1;
        escreve_login.TextChanged += escreve_login_TextChanged;
        // 
        // senha_text
        // 
        senha_text.Location = new System.Drawing.Point(559, 264);
        senha_text.Name = "senha_text";
        senha_text.Size = new System.Drawing.Size(48, 17);
        senha_text.TabIndex = 2;
        senha_text.Text = "Senha";
        senha_text.Click += senha_text_Click;
        // 
        // escreve_senha
        // 
        escreve_senha.Location = new System.Drawing.Point(559, 284);
        escreve_senha.Name = "escreve_senha";
        escreve_senha.Size = new System.Drawing.Size(100, 23);
        escreve_senha.TabIndex = 3;
        escreve_senha.TextChanged += escreve_senha_TextChanged;
        // 
        // btn_Acesso
        // 
        btn_Acesso.Cursor = System.Windows.Forms.Cursors.Default;
        btn_Acesso.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
        btn_Acesso.Location = new System.Drawing.Point(523, 313);
        btn_Acesso.Name = "btn_Acesso";
        btn_Acesso.Size = new System.Drawing.Size(169, 23);
        btn_Acesso.TabIndex = 4;
        btn_Acesso.Text = "Acessar";
        btn_Acesso.UseVisualStyleBackColor = true;
        btn_Acesso.Click += btn_Acesso_Click;
        // 
        // btn_cad
        // 
        btn_cad.Cursor = System.Windows.Forms.Cursors.Default;
        btn_cad.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
        btn_cad.Location = new System.Drawing.Point(523, 342);
        btn_cad.Name = "btn_cad";
        btn_cad.Size = new System.Drawing.Size(169, 23);
        btn_cad.TabIndex = 5;
        btn_cad.Text = "Cadastre-se";
        btn_cad.UseVisualStyleBackColor = true;
        btn_cad.Click += btn_cad_Click;
        // 
        // pictureBox1
        // 
        pictureBox1.Image = ((System.Drawing.Image)resources.GetObject("pictureBox1.Image"));
        pictureBox1.Location = new System.Drawing.Point(-362, -128);
        pictureBox1.Name = "pictureBox1";
        pictureBox1.Size = new System.Drawing.Size(768, 768);
        pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
        pictureBox1.TabIndex = 6;
        pictureBox1.TabStop = false;
        // 
        // label1
        // 
        label1.BackColor = System.Drawing.Color.FromArgb(((int)((byte)164)), ((int)((byte)0)), ((int)((byte)0)));
        label1.Font = new System.Drawing.Font("Segoe Print", 35.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)0));
        label1.ForeColor = System.Drawing.Color.White;
        label1.Location = new System.Drawing.Point(107, 176);
        label1.Name = "label1";
        label1.Size = new System.Drawing.Size(260, 105);
        label1.TabIndex = 7;
        label1.Text = "Empório";
        // 
        // label2
        // 
        label2.BackColor = System.Drawing.Color.FromArgb(((int)((byte)164)), ((int)((byte)0)), ((int)((byte)0)));
        label2.Font = new System.Drawing.Font("SimSun", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)0));
        label2.ForeColor = System.Drawing.Color.White;
        label2.Location = new System.Drawing.Point(107, 243);
        label2.Name = "label2";
        label2.Size = new System.Drawing.Size(260, 64);
        label2.TabIndex = 8;
        label2.Text = "A sua vida com mais estilo";
        // 
        // Form1
        // 
        AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
        AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
        BackColor = System.Drawing.SystemColors.ControlLightLight;
        ClientSize = new System.Drawing.Size(752, 511);
        Controls.Add(label2);
        Controls.Add(label1);
        Controls.Add(pictureBox1);
        Controls.Add(btn_cad);
        Controls.Add(btn_Acesso);
        Controls.Add(escreve_senha);
        Controls.Add(senha_text);
        Controls.Add(escreve_login);
        Controls.Add(Login_text);
        Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)0));
        Text = "Emporio_System";
        ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
        ResumeLayout(false);
        PerformLayout();
    }

    private System.Windows.Forms.Label label2;

    private System.Windows.Forms.PictureBox pictureBox1;

    private System.Windows.Forms.Label senha_text;

    private System.Windows.Forms.TextBox escreve_senha;

    private System.Windows.Forms.TextBox escreve_login;
    private System.Windows.Forms.Label Login_text;

    private System.Windows.Forms.Button btn_Acesso;

    private System.Windows.Forms.Button btn_cad;

    private System.Windows.Forms.Label Login_TelaMenu;
    private System.Windows.Forms.Label label1;
    private System.Windows.Forms.TextBox textBox2;

    #endregion
}