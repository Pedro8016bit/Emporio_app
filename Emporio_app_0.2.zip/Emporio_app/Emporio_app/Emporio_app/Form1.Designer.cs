﻿namespace Emporio_app;

partial class Form1
{
    private System.ComponentModel.IContainer components = null;

    protected override void Dispose(bool disposing)
    {
        if (disposing && (components != null))
        {
            components.Dispose();
        }

        base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
        Login_text = new System.Windows.Forms.Label();
        escreve_login = new System.Windows.Forms.TextBox();
        senha_text = new System.Windows.Forms.Label();
        escreve_senha = new System.Windows.Forms.TextBox();
        btn_Acesso = new System.Windows.Forms.Button();
        btn_cad = new System.Windows.Forms.Button();
        SuspendLayout();
        // 
        // Login_text
        // 
        Login_text.Location = new System.Drawing.Point(340, 195);
        Login_text.Name = "Login_text";
        Login_text.Size = new System.Drawing.Size(38, 18);
        Login_text.TabIndex = 0;
        Login_text.Text = "Login";
        Login_text.Click += Login_text_Click;
        // 
        // escreve_login
        // 
        escreve_login.Location = new System.Drawing.Point(340, 216);
        escreve_login.Name = "escreve_login";
        escreve_login.Size = new System.Drawing.Size(100, 23);
        escreve_login.TabIndex = 1;
        escreve_login.TextChanged += escreve_login_TextChanged;
        // 
        // senha_text
        // 
        senha_text.Location = new System.Drawing.Point(340, 257);
        senha_text.Name = "senha_text";
        senha_text.Size = new System.Drawing.Size(48, 17);
        senha_text.TabIndex = 2;
        senha_text.Text = "Senha";
        senha_text.Click += senha_text_Click;
        // 
        // escreve_senha
        // 
        escreve_senha.Location = new System.Drawing.Point(340, 277);
        escreve_senha.Name = "escreve_senha";
        escreve_senha.Size = new System.Drawing.Size(100, 23);
        escreve_senha.TabIndex = 3;
        escreve_senha.TextChanged += escreve_senha_TextChanged;
        // 
        // btn_Acesso
        // 
        btn_Acesso.Cursor = System.Windows.Forms.Cursors.Default;
        btn_Acesso.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
        btn_Acesso.Location = new System.Drawing.Point(303, 315);
        btn_Acesso.Name = "btn_Acesso";
        btn_Acesso.Size = new System.Drawing.Size(169, 23);
        btn_Acesso.TabIndex = 4;
        btn_Acesso.Text = "Acessar";
        btn_Acesso.UseVisualStyleBackColor = true;
        btn_Acesso.Click += btn_Acesso_Click;
        // 
        // btn_cad
        // 
        btn_cad.Cursor = System.Windows.Forms.Cursors.Default;
        btn_cad.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
        btn_cad.Location = new System.Drawing.Point(303, 344);
        btn_cad.Name = "btn_cad";
        btn_cad.Size = new System.Drawing.Size(169, 23);
        btn_cad.TabIndex = 5;
        btn_cad.Text = "Cadastre-se";
        btn_cad.UseVisualStyleBackColor = true;
        btn_cad.Click += btn_cad_Click;
        // 
        // Form1
        // 
        AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
        AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
        BackColor = System.Drawing.SystemColors.ControlLightLight;
        ClientSize = new System.Drawing.Size(800, 450);
        Controls.Add(btn_cad);
        Controls.Add(btn_Acesso);
        Controls.Add(escreve_senha);
        Controls.Add(senha_text);
        Controls.Add(escreve_login);
        Controls.Add(Login_text);
        Text = "Emporio_System";
        ResumeLayout(false);
        PerformLayout();
    }

    private System.Windows.Forms.Label senha_text;

    private System.Windows.Forms.TextBox escreve_senha;

    private System.Windows.Forms.TextBox escreve_login;
    private System.Windows.Forms.Label Login_text;

    private System.Windows.Forms.Button btn_Acesso;

    private System.Windows.Forms.Button btn_cad;

    private System.Windows.Forms.Label Login_TelaMenu;
    private System.Windows.Forms.TextBox textBox1;
    private System.Windows.Forms.Label label1;
    private System.Windows.Forms.TextBox textBox2;

    #endregion
}